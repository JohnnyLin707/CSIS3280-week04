<?php
if(filter_has_var(INPUT_POST, 'watchNow')){
    print 'You selected WatchNow';
}
else{
    print 'You selected WatchLater';
}