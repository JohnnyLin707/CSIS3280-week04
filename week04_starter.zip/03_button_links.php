<!doctype html><html><head><title>Basket From Array</title>
    <link rel="stylesheet"
          href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
    >
</head>
<body class="container">
<h1>Your shopping basket</h1>

    <div class="col-lg-3 text-end py-2">
        
    </div>

</body>
</html>
