<?php
$toppings = filter_input(INPUT_GET, 'toppings',options:FILTER_REQUIRE_ARRAY);

if(empty($toppings)){
    print 'Please select a topping';
}
else{
    $toppingString = implode('+',$toppings);
    print "Your selected toppings are: $toppingString";
}