<?php
// ---- (1) LOGIC -----
$id = filter_input(INPUT_GET,'id');
$title = filter_input(INPUT_POST,'title');
$price = filter_input(INPUT_POST,'price');

?>

<!-- (2) HTML Template -->
 <!doctype html>
 <html>
    <head>
        <title>PHP processor</title>
    </head>
    <body>
        id = <?= $id ?> <br>
        title = <?= $title ?> <br>
        price = <?= $price ?> <br>

    </body>
 </html>
