<?php

require_once 'inc/zeroFunction.php';
require_once 'inc/form.php';
require_once 'inc/validate.php';

// Initialize some variables
$isSubmitted = ($_SERVER['REQUEST_METHOD'] === 'POST');
$productCode = '';
$price = '';
$errors = [];

// if the form was submitted --> validate
if($isSubmitted){
    $errors = validate();
}

// create an isValid variable ... it is optional
// you can always use empty($errors)
$isValid = empty($errors);

// if the form was submitted and the data is valid
if($isSubmitted && $isValid){
    print 'Your input data was error free';
}
else{
    displayForm($isSubmitted,$isValid,$errors,$productCode,$price);
}

